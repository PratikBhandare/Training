import { poolConnect } from "./db";

export const pool = poolConnect;